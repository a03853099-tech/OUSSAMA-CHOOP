مشروع إبراهيم وأسامة Free Fire
===============================

محتويات المشروع:
- server.js: سيرفر Express و Socket.IO و API.
- public/index.html: واجهة الموقع بالعربية مرتبطة بالـ API.
- SQLite: قاعدة بيانات اللاعبين والنقاط والطلبات.
- render.yaml: إعداد نشر Render مع قرص دائم.

التشغيل:
1. ثبّت Node.js 20 أو أحدث.
2. نفّذ npm install
3. عيّن متغير ADMIN_PASSWORD إلى كلمة سر الإدارة.
4. عيّن TOKEN_SECRET إلى سلسلة عشوائية طويلة وسرية.
5. عيّن DB_PATH إلى مسار دائم لقاعدة البيانات (مثلاً ./data.sqlite).
6. نفّذ npm start ثم افتح http://localhost:3000

النشر:
- ارفع جميع محتويات المجلد إلى GitHub.
- في Render اختر New ثم Blueprint واربط المستودع.
- أضف ADMIN_PASSWORD في Environment.
- احتفظ برابط الخدمة بعد اكتمال النشر.

تنبيه: الملف render.yaml يطلب خطة Starter وقرصاً دائماً؛ قد تكون هناك تكلفة حسب أسعار Render الحالية.
لا تضع كلمة سر الإدارة أو TOKEN_SECRET داخل ملفات الواجهة أو GitHub.
